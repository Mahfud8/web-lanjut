<div class="container mt-3">
 <div class="">
  <div class="container" align="center">
   <h1 class="display-4">About Me</h1>
   
   <p class="lead">Toko Tanaman Hias ABC</p>
   <p class="lead">Jl. Tentara Pelajar 12345 Semarang </p>
   <p class="lead">Phone 024-12345678 </p>
  </div>
 </div>

</div>