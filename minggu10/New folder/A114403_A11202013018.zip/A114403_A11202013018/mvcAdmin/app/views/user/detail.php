<div class="container mt-3">
 <div class="card" style="width: 18rem;">

  <div class="card-body">
   <h5 class="card-title"><?= $data['usr']['username']; ?></h5>
   <p class="card-text"><?= $data['usr']['password']; ?></p>
   <a href="<?= BASEURL; ?>/user" class="btn btn-primary">Kembali</a>
  </div>
 </div>

</div>