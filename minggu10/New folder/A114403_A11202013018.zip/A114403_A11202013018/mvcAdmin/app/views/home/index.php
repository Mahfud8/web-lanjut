<div class="container mt-3">
 <div class="jumbotron">
  <p class="lead"></p>
 </div>
 <h1 class="text-muted">Selamat Datang di Sistem Administrator Toko Tanaman Hias</h1>
</div>