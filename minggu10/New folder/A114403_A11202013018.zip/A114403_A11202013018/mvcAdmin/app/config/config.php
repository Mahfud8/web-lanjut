<?php
define('BASEURL', 'http://localhost/web-lanjut\minggu10\mvcAdmin\mvcAdmin\public');
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'dbOrder');